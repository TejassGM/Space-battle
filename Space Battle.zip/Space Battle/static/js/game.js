const socket = io();

const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");

const startScreen = document.getElementById("startScreen");
const gameScreen = document.getElementById("gameScreen");
const gameOverScreen = document.getElementById("gameOverScreen");

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 800;
canvas.height = 600;

let playerName = "";
let myId = null;
let isGameOver = false;

let player = { x: 400, y: 500, size: 20 };

let gameState = {
    players: {},
    bullets: [],
    enemies: [],
    scores: {},
    boss: null,
    boss_bullets: []
};

socket.on("your_id", (data) => {
    myId = data.id;
});

socket.on("game_over", (data) => {
    isGameOver = true;
    document.getElementById("finalScore").innerText =
        "Your Score: " + data.score;
    gameScreen.style.display = "none";
    gameOverScreen.style.display = "flex";
});

if (restartBtn) {
    restartBtn.addEventListener("click", () => location.reload());
}

if (startBtn) {
    startBtn.addEventListener("click", () => {
        const nameInput = document.getElementById("playerName");
        playerName = nameInput.value.trim();

        if (playerName === "") {
            alert("Please enter your name");
            return;
        }

        socket.emit("set_name", { name: playerName });

        startScreen.style.display = "none";
        gameScreen.style.display = "block";
    });
}

socket.on("game_state", (data) => {
    gameState = data;
});

let mouse = { x: player.x, y: player.y };

canvas.addEventListener("mousemove", (e) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
});

function updateMovement() {
    if (isGameOver) return;

    player.x += (mouse.x - player.x - player.size / 2) * 0.08;
    player.y += (mouse.y - player.y - player.size / 2) * 0.08;

    player.x = Math.max(0, Math.min(canvas.width - player.size, player.x));
    player.y = Math.max(0, Math.min(canvas.height - player.size, player.y));

    socket.emit("player_move", player);
}

canvas.addEventListener("click", () => {
    if (isGameOver) return;
    socket.emit("shoot", {
        x: player.x + player.size / 2,
        y: player.y
    });
});

function render() {

    if (gameScreen.style.display === "none") {
        requestAnimationFrame(render);
        return;
    }

    updateMovement();

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // -------- PLAYERS --------
    for (let id in gameState.players) {
        let p = gameState.players[id];

        ctx.fillStyle = id === myId ? "#00f7ff" : "#ff00ff";
        ctx.fillRect(p.x, p.y, p.size, p.size);

        ctx.fillStyle = "red";
        ctx.fillRect(p.x, p.y - 8, p.size, 4);

        ctx.fillStyle = "lime";
        ctx.fillRect(p.x, p.y - 8, p.size * (p.health / 100), 4);

        ctx.fillStyle = "white";
        ctx.font = "14px Arial";
        ctx.textAlign = "center";
        ctx.fillText(p.name || "Player", p.x + p.size / 2, p.y - 15);
    }

    // -------- PLAYER BULLETS --------
    gameState.bullets.forEach((b) => {
        ctx.fillStyle = "yellow";
        ctx.fillRect(b.x, b.y, 4, 12);
    });

    // -------- ENEMIES --------
    gameState.enemies.forEach((e) => {
        ctx.fillStyle = "#ff3c00";
        ctx.beginPath();
        ctx.arc(e.x + 10, e.y + 10, 10, 0, Math.PI * 2);
        ctx.fill();
    });

    // -------- BOSS --------
    if (gameState.boss) {
        let b = gameState.boss;

        ctx.fillStyle = "purple";
        ctx.fillRect(b.x, b.y, b.width, b.height);

        ctx.fillStyle = "red";
        ctx.fillRect(b.x, b.y - 15, b.width, 8);

        ctx.fillStyle = "lime";
        ctx.fillRect(
            b.x,
            b.y - 15,
            b.width * (b.health / 300),
            8
        );
    }

    // -------- BOSS BULLETS --------
    gameState.boss_bullets.forEach((b) => {
        ctx.fillStyle = "red";
        ctx.fillRect(b.x, b.y, 6, 12);
    });

    let myScore = gameState.scores[myId] || 0;
    let myHealth = gameState.players[myId]?.health || 100;

    document.getElementById("playerDisplay").innerText =
        "Player: " + playerName;
    document.getElementById("score").innerText =
        "Score: " + myScore;
    document.getElementById("health").innerText =
        "Health: " + myHealth;

    requestAnimationFrame(render);
}

render();
