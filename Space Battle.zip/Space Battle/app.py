from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
import eventlet
import random
import time

eventlet.monkey_patch()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

players = {}
bullets = []
enemies = []
scores = {}

boss = None
boss_bullets = []
BOSS_HEALTH = 300
BOSS_SPAWN_SCORE = 200
last_boss_shot = 0

@app.route('/')
def index():
    return render_template("index.html")

# ================= CONNECT =================
@socketio.on('connect')
def handle_connect():
    sid = request.sid

    players[sid] = {
        "x": 400,
        "y": 500,
        "size": 20,
        "health": 100,
        "name": "Player"
    }

    scores[sid] = 0
    emit("your_id", {"id": sid})

# ================= DISCONNECT =================
@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    players.pop(sid, None)
    scores.pop(sid, None)

# ================= PLAYER MOVEMENT =================
@socketio.on('player_move')
def handle_move(data):
    sid = request.sid
    if sid in players:
        players[sid]["x"] = data["x"]
        players[sid]["y"] = data["y"]

# ================= SET NAME =================
@socketio.on("set_name")
def set_name(data):
    sid = request.sid
    if sid in players:
        players[sid]["name"] = data["name"]

# ================= SHOOT =================
@socketio.on('shoot')
def handle_shoot(data):
    bullets.append({
        "x": data["x"],
        "y": data["y"],
        "owner": request.sid
    })

# ================= GAME LOOP =================
def game_loop():
    global boss, last_boss_shot

    while True:
        socketio.sleep(0.03)

        # ---------- ENEMY SPAWN ----------
        if not boss and random.randint(1, 40) == 1:
            enemies.append({
                "x": random.randint(0, 780),
                "y": 0,
                "size": 20
            })

        # ---------- MOVE ENEMIES ----------
        for enemy in enemies[:]:
            enemy["y"] += 2
            if enemy["y"] > 600:
                enemies.remove(enemy)

        # ---------- MOVE PLAYER BULLETS ----------
        for bullet in bullets[:]:
            bullet["y"] -= 7
            if bullet["y"] < 0:
                bullets.remove(bullet)

        # ---------- BULLET HITS ENEMY ----------
        for enemy in enemies[:]:
            for bullet in bullets[:]:
                if (
                    bullet["x"] < enemy["x"] + enemy["size"] and
                    bullet["x"] + 5 > enemy["x"] and
                    bullet["y"] < enemy["y"] + enemy["size"] and
                    bullet["y"] + 10 > enemy["y"]
                ):
                    enemies.remove(enemy)
                    bullets.remove(bullet)
                    scores[bullet["owner"]] += 10
                    break

        # ---------- SPAWN BOSS ----------
        if not boss:
            for sid in scores:
                if scores[sid] >= BOSS_SPAWN_SCORE:
                    boss = {
                        "x": 250,
                        "y": 50,
                        "width": 300,
                        "height": 80,
                        "health": BOSS_HEALTH,
                        "direction": 1
                    }
                    break

        # ---------- MOVE BOSS ----------
        if boss:
            boss["x"] += 3 * boss["direction"]
            if boss["x"] <= 0 or boss["x"] + boss["width"] >= 800:
                boss["direction"] *= -1

            # Boss shoots every 1.2 sec
            if time.time() - last_boss_shot > 1.2:
                boss_bullets.append({
                    "x": boss["x"] + boss["width"] // 2,
                    "y": boss["y"] + boss["height"]
                })
                last_boss_shot = time.time()

        # ---------- MOVE BOSS BULLETS ----------
        for b in boss_bullets[:]:
            b["y"] += 6
            if b["y"] > 600:
                boss_bullets.remove(b)

        # ---------- PLAYER BULLETS HIT BOSS ----------
        if boss:
            for bullet in bullets[:]:
                if (
                    bullet["x"] < boss["x"] + boss["width"] and
                    bullet["x"] + 5 > boss["x"] and
                    bullet["y"] < boss["y"] + boss["height"] and
                    bullet["y"] + 10 > boss["y"]
                ):
                    bullets.remove(bullet)
                    boss["health"] -= 10
                    scores[bullet["owner"]] += 5

                    if boss["health"] <= 0:
                        scores[bullet["owner"]] += 200
                        boss = None
                        boss_bullets.clear()
                    break

        # ---------- BOSS BULLETS HIT PLAYER ----------
        for b in boss_bullets[:]:
            for sid, player in list(players.items()):

                px = player["x"]
                py = player["y"]
                psize = player["size"]

                if (
                    b["x"] < px + psize and
                    b["x"] + 6 > px and
                    b["y"] < py + psize and
                    b["y"] + 12 > py
                ):
                    player["health"] -= 20
                    boss_bullets.remove(b)

                    if player["health"] <= 0:
                        socketio.emit("game_over", {
                            "score": scores.get(sid, 0)
                        }, room=sid)
                        players.pop(sid, None)
                        scores.pop(sid, None)
                    break

        socketio.emit("game_state", {
            "players": players,
            "bullets": bullets,
            "enemies": enemies,
            "scores": scores,
            "boss": boss,
            "boss_bullets": boss_bullets
        })

socketio.start_background_task(game_loop)

if __name__ == '__main__':
    socketio.run(app, debug=True)
